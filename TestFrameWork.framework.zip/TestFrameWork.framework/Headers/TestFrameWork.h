//
//  TestFrameWork.h
//  TestFrameWork
//
//  Created by zengzhihui on 2018/3/26.
//  Copyright © 2018年 zengzhihui. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TestFrameWork.
FOUNDATION_EXPORT double TestFrameWorkVersionNumber;

//! Project version string for TestFrameWork.
FOUNDATION_EXPORT const unsigned char TestFrameWorkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestFrameWork/PublicHeader.h>
#import "TestObject.h"

